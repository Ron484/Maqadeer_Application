package controller;

/**
 *
 * @author Ekram
 */
public interface Category {
    
    String MAIN_COURSE = "رئيسية";
    String DRINKS = "مشروبات";
    String APPETIZER = "مقبلات";
    String DESSERT = "حلويات";   
}