package controller;

public class CurrentUser {
    
    
    /*  This id will be assigned when user is loged in.
        It will used to keep all information foodstuff, recipes, etc. 
        that related for him. 
    */    
    public static int id;    
}
